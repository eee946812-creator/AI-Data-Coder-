# 10 — Minimal / Modern Design 2026 / ดีไซน์มินิมอลโมเดิร์น

> **id:** `design.minimal`
> **provides:** design-tokens, layout, typography, color, ui-spec, motion
> **consumes:** reasoning, fresh-facts, ui-target
> Links into `web.code` (hard) and `roblox.luau` GUI (optional). Verify trends live before committing — see `02`.

---

## 1. 2026 design stance / จุดยืน
Minimalism in 2026 is **intentional**, not bare. Clean structure + one strong accent (bold type, a color pop, or micro-detail). Two live currents to choose between by brand:
- **Refined minimal / glass** — whitespace, soft depth, calm futurism (good for dashboards, SaaS, corporate). [digitalsilk/squarespace 2026]
- **Tactile brutalism** — sharp geometry, 1px solid borders, stark type, high contrast (good for creative/tech differentiation). [fireart 2026]

Pick ONE direction per product; do not mix randomly.

## 2. Design tokens (provide these) / โทเคน
```jsonc
{
  "color": {
    "bg":        "#0A0A0A",   // dark-first; true black saves OLED power
    "surface":   "#141414",
    "text":      "#F5F5F5",
    "muted":     "#A1A1A1",
    "accent":    "#4F81BD",   // single accent; swap per brand
    "border":    "#262626"    // 1px solid for tactile look
  },
  "space":   [4, 8, 12, 16, 24, 32, 48, 64],   // 4px base scale
  "radius":  { "sm": 6, "md": 12, "lg": 20, "glass": 16 },
  "type": {
    "display": "clamp(2rem, 6vw, 4.5rem)",     // oversized headline
    "body":    "clamp(1rem, 1.2vw, 1.125rem)",
    "mono":    "ui-monospace, 'JetBrains Mono', monospace" // metadata/buttons
  }
}
```
Token names are stable contracts — consumers (`web.code`, `roblox.luau`) read these keys.

## 3. Typography / ตัวอักษร
- Variable fonts (single file, weight/width axes) — personality + small payload.
- Pairing that reads "2026": **neo-serif heading + monospace metadata**, or one bold variable sans.
- Hierarchy by scale & weight, not by many fonts (max 2 families). Heading order must be semantic (H1→H6) for MX/SEO.

## 4. Layout & motion / เลย์เอาต์และโมชัน
- Mobile-first; experience-first across devices.
- Asymmetry / broken grid for movement, but keep content order logical.
- Glassmorphism ONLY on key surfaces (cards, nav) — test contrast/readability.
- Motion = functional: micro-interactions, scroll-driven type. Every animation must delight, inform, or direct — else cut it.

## 5. Accessibility & performance (non-negotiable) / เข้าถึงได้และเร็ว
- Contrast ≥ 4.5:1; keyboard nav; screen-reader labels; honor `prefers-reduced-motion`.
- Prefer SVG/CSS over heavy photos; lazy-load; lean code (sustainability + speed).

## 6. Handoff contract / ส่งต่อ
Output a token file + a one-page UI spec (states: default/hover/active/disabled/loading/empty/error). `web.code` and Roblox GUI consume the same tokens so the look stays consistent across platforms.
