# 90 — Naming Conventions / กฎการตั้งชื่อ (ชัดเจน = เร็ว)

> **id:** `meta.naming` · **provides:** naming, structure · **consumes:** `*`
> Clear, predictable names = faster reading, diffing, and AI/agent parsing. ตั้งชื่อชัด หาเร็ว แก้เร็ว

---

## 1. Files & folders / ไฟล์และโฟลเดอร์
- Folders/docs: `NN-kebab-name` (numeric prefix orders them; speeds navigation).
- One file = one responsibility; filename = the thing it exports.
- No spaces, no Thai in filenames (ASCII kebab-case) → safe on GitHub, URLs, CLIs.

## 2. Per-language casing / ตามภาษา
| Context | Style | Example |
|---------|-------|---------|
| Roblox API / Instance | PascalCase | `RemoteEvent`, `PlayerData` |
| Luau local/func/member | camelCase | `playerCoins`, `addScore` |
| Luau constant | LOUD_SNAKE_CASE | `MAX_HEALTH` |
| Luau private | `_camelCase` | `_internalState` |
| JS/TS var/func | camelCase | `userId`, `postScore` |
| JS/TS class/type | PascalCase | `WalletService` |
| CSS token/var | `--kebab` | `--accent`, `--radius-md` |
| Firestore collection | lowerCamel plural | `scores`, `userProfiles` |
| API route | lower kebab + version | `/v1/post-score` |
| Env / secret | UPPER_SNAKE | `FIREBASE_API_KEY` |

## 3. Semantic prefixes / คำนำหน้าให้ความหมาย
- Booleans: `is/has/can/should` (`isReady`, `hasAccess`).
- Async/IO that can fail: verb + Async or returns `(ok, err)` (`fetchUserAsync`).
- Events: `on<Subject><Verb>` (`onPlayerJoined`).
- Handlers: `handle<Event>` (`handleSubmit`).

## 4. Speed-by-clarity rules / กฎให้เร็วด้วยความชัด
- Name reveals intent without a comment. If you need a comment to explain the name, rename it.
- No abbreviations except well-known sets (`RGB`, `XYZ`, `URL`). For acronyms in names, don't all-caps mid-word: `aJsonVariable`, `makeHttpCall`.
- Keep names searchable & unique enough to grep in one shot.
