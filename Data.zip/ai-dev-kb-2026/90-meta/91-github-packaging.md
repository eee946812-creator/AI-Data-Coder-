# 91 — GitHub Packaging / อัปขึ้น GitHub และกฎ ≤ 25MB

> **id:** `meta.github` · **provides:** packaging, repo-layout, ci · **consumes:** naming, structure, `*`
> Every file ≤ 25 MB, repo clean, agent- and human-readable. ทุกไฟล์ไม่เกิน 25MB และอัปขึ้น GitHub ได้

---

## 1. The 25 MB rule / กฎ 25MB
- Hard cap: **each file ≤ 25 MB.** (GitHub's web UI also blocks >25 MB uploads; warns at 50 MB; hard repo limit 100 MB without LFS.)
- If an asset exceeds 25 MB → split it, compress it, or move it to **Git LFS** / external storage and reference by URL.
- Markdown KB files like these are KBs in size — well within limits.

```bash
# pre-commit guard: fail if any tracked file > 25MB
find . -type f -not -path './.git/*' -size +25M -print | grep . \
  && { echo "FILE >25MB — split or use LFS"; exit 1; } || echo "size OK"
```

## 2. Repo layout / โครงสร้าง repo
```
repo-root/
  README.md
  manifest.json          # capability graph (machine-readable)
  00-core/ 10-design/ 20-web/ 30-roblox/ 40-backend/ 90-meta/
  .gitignore
  .github/workflows/ci.yml
  LICENSE
```

## 3. .gitignore essentials / กันไฟล์ที่ไม่ควรขึ้น
```
node_modules/
dist/  build/
.env  *.key  *.pem        # NEVER commit secrets
*.rbxl  *.rbxlx           # large Roblox place files -> LFS or release assets
.DS_Store
```

## 4. Minimal CI / CI ขั้นต่ำ
```yaml
# .github/workflows/ci.yml
name: ci
on: [push, pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: size guard (<=25MB)
        run: |
          if find . -path ./.git -prune -o -type f -size +25M -print | grep .; then
            echo "::error::file over 25MB"; exit 1; fi
      # add: luau-analyze for .luau, eslint/tsc for web, JSON validate for manifest
```

## 5. Commit & push / คอมมิตและพุช
```bash
git init && git add .
git commit -m "feat: ai-dev-kb-2026 modular capability KB"
git branch -M main
git remote add origin https://github.com/<you>/ai-dev-kb-2026.git
git push -u origin main
```
Conventional commits (`feat:`, `fix:`, `docs:`) → clean history, easy automation.

## 6. Release checklist / เช็คก่อนปล่อย
- [ ] `manifest.json` validates as JSON.
- [ ] No secrets committed (`git secrets`/scan).
- [ ] All files ≤ 25 MB.
- [ ] README explains the capability-graph philosophy.
- [ ] Names follow `90-naming-conventions.md`.
