# ai-dev-kb-2026 🧩

A **modular, composable knowledge base** for advanced minimal/modern design, web coding, Roblox Studio (Luau), and Firebase API/server management — with **verified 2026 data**.

ชุดข้อมูล (knowledge base) แบบโมดูลาร์สำหรับ: ดีไซน์มินิมอลโมเดิร์น, เขียนเว็บ, Roblox Studio (Luau), จัดการ API/เซิร์ฟเวอร์ด้วย Firebase — ข้อมูลปี **2026** ที่ตรวจจากเว็บจริง

---

## Core idea — capability links, not hardcoded chains / หัวใจ: ต่อกันได้ ไม่บังคับเส้นทาง

Each module declares what it **`provides`** and what it **`consumes`** (as tags in `manifest.json`).
A link **X → Y** exists whenever `X.provides ∩ Y.consumes ≠ ∅`.

> **"If A can connect to B, allow it."** — never force a fixed A→B→C pipeline.
> ถ้า A ต่อกับ B ได้ก็ทำ ไม่ใช่ต้องเป็น A→B→C เท่านั้น

So the same KB serves a static site (design + web, no backend), a Roblox economy (luau + firebase, no web UI), or a full stack — without rewriting any rules. The graph adapts to the task.

## Module map / แผนผังโมดูล

| Module | id | provides | links to |
|--------|----|----------|----------|
| `00-core/00-reasoning-engine.md` | core.reasoning | reasoning, decomposition | everything |
| `00-core/01-error-checking.md` | core.errorcheck | validation, qa | everything (gate) |
| `00-core/02-web-research-2026.md` | core.research | fresh-facts, citations | any volatile fact |
| `00-core/03-composition-rules.md` | core.compose | composition, routing | the graph engine |
| `10-design/10-minimal-modern-2026.md` | design.minimal | design-tokens, ui-spec | web (hard), roblox GUI (opt) |
| `20-web/20-web-coding-2026.md` | web.code | web-ui, frontend | design, firebase |
| `30-roblox/30-roblox-luau-2026.md` | roblox.luau | game-logic, client-server | firebase, design (opt) |
| `40-backend/40-firebase-api-server-2026.md` | backend.firebase | api-endpoint, auth, data-store | web + roblox (both) |
| `90-meta/90-naming-conventions.md` | meta.naming | naming | everything |
| `90-meta/91-github-packaging.md` | meta.github | packaging, ci | final artifacts |

## How to use / วิธีใช้

1. State the task → `core.reasoning` decomposes it into capability needs (tags).
2. `core.compose` resolves which modules link (see its algorithm).
3. `core.research` verifies every 2026 fact live before you rely on it.
4. Build, then pass `core.errorcheck` pre- and post-flight.
5. `meta.naming` + `meta.github` finalize names and packaging (≤25 MB/file).

Always-on modules (reasoning, errorcheck, research) attach to every task automatically.

## Hard constraints / ข้อบังคับ
- ✅ Every file ≤ **25 MB**, GitHub-ready.
- ✅ **2026** data, verified from the live web (sources cited in `02`).
- ✅ Clear naming for speed.
- ✅ Advanced reasoning on hard problems; error-check before every action.

## Quick start with an AI agent / เริ่มเร็วกับ AI
> "Load `manifest.json`. Resolve modules for: `<my task>`. Follow each linked module's rules, verify 2026 facts via core.research, and run core.errorcheck before output."

## License
MIT (suggested). Replace as needed.
