# 40 — Firebase: API & Server Management 2026 / จัดการ API และเซิร์ฟเวอร์

> **id:** `backend.firebase`
> **provides:** api-endpoint, auth, data-store, server-logic, realtime, ai-logic
> **consumes:** reasoning, validation, fresh-facts, web-api-client, game-logic
> One provider, many consumers: `web.code` AND `roblox.luau` can both consume the same endpoints/data. Re-verify versions live (`02`).

---

## 1. 2026 Firebase shape / ภาพรวม
Firebase is a serverless super-platform: Auth · Firestore · **SQL Connect (Postgres)** · Cloud Functions · Cloud Run · AI Logic · Hosting · App Check · Analytics/BigQuery.

**Architecture principle:** *thin client, smart backend, zero-trust.* All permissions live in **Security Rules + Functions/Run**, never the client.

## 2. Compute: events vs logic / เลือกที่รันโค้ด
| Need | Use | Why |
|------|-----|-----|
| Auth trigger, Firestore trigger, light background job | **Cloud Functions** | event-driven, scales to zero |
| Long-running API, webhook, AI inference, heavy business logic | **Cloud Run** | no timeout pressure, full control |

> 2026 rule of thumb: **Functions for events, Cloud Run for logic.** (Cloud Functions also supports **Dart** experimentally in 2026.)

## 3. Data: pick the store / เลือกฐานข้อมูล
- **Firestore** — realtime, offline-first, multi-region; Enterprise adds full-text search, geospatial, JOIN-via-subquery. Avoid deep nested subcollections, unpaginated queries, over-listening with `onSnapshot`.
- **SQL Connect (Cloud SQL Postgres, default v17)** — when you need relational data, SQL queries, realtime sync + offline cache. Native SQL instead of GraphQL.
- Pattern: denormalize for read-optimized paths; precompute heavy aggregates in Functions; cache hot reads (MemoryStore/edge); track read cost per feature.

## 4. Auth / ยืนยันตัวตน
Passwordless by default: email link, OAuth, **passkeys**, phone (2026 Phone Number Verification = SIM-based, no SMS OTP). Role-based access via **custom claims** (`admin`, `editor`, ...) used in Rules + Functions + frontend gating.

## 5. API design & security / ออกแบบ API และความปลอดภัย
- Stable, versioned endpoints (`/v1/...`); clear request/response schemas; validate every input server-side.
- **App Check** on AI/sensitive endpoints — 2026 adds **single-use token replay protection**.
- **Firebase AI Logic** keeps the Gemini key on Google's servers (never on client); use **server prompt templates** (now support tool calls + chat) so you can change prompts/models without an app update. Use **template-only mode** to ignore client-sent prompt overrides.
- ⚠️ **Imagen models shut down 2026-06-24** → use Gemini Image (`gemini-2.5-flash-image`, "Nano Banana"). ⚠️ **Firebase Studio sunsets 2027-03-22** → AI Studio / Antigravity.

## 6. Example: one endpoint, two consumers / หนึ่ง endpoint สองผู้ใช้
```js
// Cloud Run service (Node) — consumed by web.code AND roblox.luau
// POST /v1/score  { userId, score }
import { getFirestore } from "firebase-admin/firestore";
export async function postScore(req, res) {
  const { userId, score } = req.body ?? {};
  if (typeof userId !== "string" || typeof score !== "number" || score < 0)
    return res.status(400).json({ error: "invalid input" }); // validate first
  const db = getFirestore();
  await db.collection("scores").doc(userId)
    .set({ best: score, at: Date.now() }, { merge: true });
  return res.json({ ok: true });
}
```
Web uses the Firebase Web SDK or fetches `/v1/score`; Roblox calls the same `/v1/score` via `HttpService` (server-side). The backend is the single source of truth.

## 7. Cost & scale guards / คุมต้นทุนและสเกล
Estimate reads/writes per feature; paginate; multi-region only when latency demands; offload heavy compute to Functions/Run; watch quotas. Run `core.errorcheck` Firebase section before deploy.
