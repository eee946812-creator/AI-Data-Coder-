# 03 — Composition Rules / กฎการต่อโมดูล (ยืดหยุ่น ไม่บังคับ)

> **id:** `core.compose` · **always_on:** true
> **provides:** composition, routing
> **consumes:** `*`
> Core idea: **"If A can connect to B, allow it."** Capability-based linking, never a hardcoded chain. ถ้าต่อกันได้ก็ต่อ ไม่บังคับว่าต้องเป็นเส้นทางเดียว

---

## 1. The model / โมเดล
Every module declares two tag sets in `manifest.json`:
- `provides[]` — capabilities it outputs.
- `consumes[]` — capabilities it can accept.

**Link rule:** module **X → Y** is *valid* when `X.provides ∩ Y.consumes ≠ ∅`.
- `*` matches anything.
- A module may have **many** valid links — choose by the task's needs, not by a fixed order.
- `weight 1.0` = hard/structural link; `weight < 1.0` = **optional** (use only if it improves the result).

## 2. Why not hardcode / ทำไมไม่ฟิกซ์เส้นทาง
A rigid "web → firebase → design" chain breaks the moment a task needs only two of them, or a different pairing. Capability tags let the same KB serve a static landing page (design + web, no backend), a Roblox economy (luau + firebase, no web UI), or a full stack — without editing the rules.

## 3. Resolution algorithm / อัลกอริทึมจับคู่
```
1. Decompose the task into needs[] (tags). // from core.reasoning
2. For each need, find modules whose provides ⊇ need.
3. Build the candidate graph of valid X→Y links.
4. Drop optional (weight<1.0) links that don't add value.
5. Always attach: core.reasoning, core.errorcheck, core.research.
6. Apply meta.naming + meta.github to the final artifacts.
7. If two providers satisfy the same need, pick via the reasoning trade-off table.
```

## 4. Worked examples / ตัวอย่าง
- **Modern marketing site:** needs `design-tokens, web-ui`. → `design.minimal → web.code`. No firebase unless a form/auth/data need appears. (anti-rule: don't force a backend.)
- **Roblox shop with saved data:** needs `game-logic, data-store, auth`. → `backend.firebase → roblox.luau` (HttpService/Open Cloud). `design.minimal → roblox.luau` is *optional* (only if building a GUI).
- **Web app + login + DB:** needs `web-ui, auth, data-store, api-endpoint`. → `design.minimal → web.code`, `backend.firebase → web.code`.
- **Cross-platform leaderboard:** `backend.firebase` provides `realtime`/`data-store` consumed by BOTH `web.code` and `roblox.luau` simultaneously — one provider, two consumers. Allowed.

## 5. Conflict & priority / ความขัดแย้ง
- Security/correctness links always win over convenience links.
- If a hard link and a constraint (e.g. 25 MB) conflict, the constraint wins; re-plan.
- Record any dropped link and why (traceability).
