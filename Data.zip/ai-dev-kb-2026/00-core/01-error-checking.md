# 01 — Error Checking / ตรวจหาข้อผิดพลาดก่อนทุกครั้ง

> **id:** `core.errorcheck` · **always_on:** true
> **provides:** validation, qa, safety-gate
> **consumes:** `*`
> Run the PRE-FLIGHT gate before producing any artifact, and the POST-FLIGHT gate before declaring "done". ตรวจก่อนส่ง ทุกครั้ง ไม่มีข้อยกเว้น

---

## A. PRE-FLIGHT (before writing code/design) / ก่อนเริ่ม
- [ ] Goal restated and confirmed against the actual request.
- [ ] All volatile facts (versions, prices, APIs, deprecations) verified live — see `02-web-research-2026.md`.
- [ ] Inputs validated: types, ranges, null/empty, encoding, timezone, units.
- [ ] Constraints loaded: ≤25 MB/file, GitHub-ready, target platform, naming rules.
- [ ] Security pre-check: secrets NOT in client code; trust boundary identified ("never trust the client").

## B. DOMAIN CHECKS / เช็คตามโดเมน

### Web
- [ ] No secret keys in frontend bundle (use env vars / server).
- [ ] Accessibility: semantic HTML, heading order H1→H6, ARIA labels, color contrast ≥ 4.5:1.
- [ ] Performance budget: lazy-load images, avoid plugin/JS bloat, mobile-first.
- [ ] Error + loading + empty states all handled.

### Roblox / Luau
- [ ] `--!strict` typing on; no legacy `wait()` / `spawn()` (use `task.wait` / `task.spawn`).
- [ ] **Never trust the client** — validate every RemoteEvent/RemoteFunction arg on the server.
- [ ] No `while true do ... end` without `task.wait`; no unbounded `:Connect` leaks (disconnect/`:Once`).
- [ ] `pcall` around `HttpService`, `DataStore`, and any yielding call that can fail.
- [ ] DataStore writes throttled & retried (budget-aware).

### Firebase / Backend
- [ ] Security Rules deny by default; permissions live in Rules + Functions, NOT the client.
- [ ] Firestore queries paginated; no unbounded `onSnapshot`; indexes defined.
- [ ] App Check enabled for AI Logic / sensitive endpoints (2026: single-use replay protection available).
- [ ] Cost guard: reads/writes estimated; hot reads cached; heavy work precomputed in Functions/Cloud Run.

## C. POST-FLIGHT (before "done") / ก่อนบอกว่าเสร็จ
- [ ] Code compiles / type-checks (`luau-analyze` for Luau; tsc/lint for web).
- [ ] Edge cases tested: empty, max, concurrent, offline, malformed input.
- [ ] Each output file ≤ 25 MB; names follow `90-meta/90-naming-conventions.md`.
- [ ] Citations attached for any current-fact claim.
- [ ] One-line risk note: what is the most likely way this still breaks?

## D. Failure handling / เมื่อพลาด
Return `success, result` or a Result type — do not throw except to reject invalid usage. Surface the *reason*, not just "error".
