# 02 — Live Web Research / ดึงข้อมูลล่าสุดจากเว็บจริงเท่านั้น

> **id:** `core.research` · **always_on:** true
> **provides:** fresh-facts, citations, version-check
> **consumes:** volatile-fact, version, pricing, api-spec
> Rule: **NEVER state a current fact from memory.** Verify on the live web first, then cite. ห้ามเดา ต้องเปิดเว็บจริงก่อนเสมอ

---

## 1. What MUST be verified live / สิ่งที่ต้องเช็คสด
Versions · pricing/quotas · API surfaces & method names · deprecation dates · "latest"/"current" anything · who-holds-a-role · platform limits. If a fact can change after the model's training cutoff, **search before using it.**

## 2. How to research / วิธีค้น
1. Query short (1–6 words), include the year only when it sharpens results ("Firebase release notes", "Luau type solver 2026").
2. Prefer **primary sources**: official docs, release-notes pages, vendor blogs, GitHub repos. Avoid SEO listicles for hard facts.
3. Fetch the full page when a snippet is thin.
4. Cite every current-fact claim with a link. If sources conflict, say so and prefer the newest primary source.
5. If a fact cannot be verified, label it `UNVERIFIED` — never present it as current truth.

## 3. Verified 2026 anchor facts (re-check before relying) / ข้อเท็จจริงปี 2026 ที่ตรวจแล้ว
> These were verified on 2026-06-30. Treat as a *starting point*, not gospel — re-verify volatile items.

**Firebase (2026)**
- Imagen models **deprecated, shut down 2026-06-24** → migrate to Gemini Image ("Nano Banana", e.g. `gemini-2.5-flash-image`). [firebase.google.com/support/releases]
- **Firebase SQL Connect** (Postgres on Cloud SQL): realtime sync, offline cache, native SQL queries. Default Postgres = v17. [firebase.blog Cloud Next '26]
- **Firebase AI Logic**: server prompt templates support tool calls + chat sessions; App Check **single-use replay protection** from May 2026. [firebase.blog]
- **Firebase Studio is being sunset 2027-03-22** → migrate to Google AI Studio / Google Antigravity. [firebase.google.com/support/releases]
- Rule of thumb: **Cloud Functions for events, Cloud Run for long-running logic/APIs/AI inference.** [community 2026]
- Firestore Enterprise: full-text search, geospatial queries, JOIN-via-subquery. JS SDK ≈ v12.7.x; Admin Node ≈ v14.x; CLI ≈ v15.x (re-check).

**Roblox / Luau (2026)**
- Script files use the **`.luau`** extension; Studio warns on legacy `wait()`.
- **New Type Solver + Non-Strict-by-Default** rolled out of beta (late 2025→2026); configurable via Scripting workspace properties. [devforum.roblox.com]
- `luau-analyze` = CLI type checker/linter; config via `--!` comments and `.luaurc`. `luau-lsp` for editors. [github.com/luau-lang/luau]
- Style: PascalCase for Roblox APIs, camelCase locals, `LOUD_SNAKE_CASE` constants, `_private`. [roblox.github.io/lua-style-guide]
- New Flexible Studio UI permanent from Jan 5, 2026.

**Web design (2026)**
- Dual movement: "tactile brutalism" (sharp geometry, 1px borders, stark type) vs refined minimalism; both over soft-UI. [fireart.studio]
- **Machine Experience (MX)**: clean semantic HTML + perfect H1→H6 + ARIA so LLM agents can parse the site. [fireart.studio]
- Dark-first defaults (true black saves OLED power); SVG/CSS over heavy images; variable fonts + kinetic typography. [multiple 2026]
- Minimalism is now "intentional": whitespace, asymmetry/broken grids, glassmorphism on key surfaces only. [digitalsilk, squarespace]

## 4. Citation format / รูปแบบอ้างอิง
`Claim. [source-domain, date]` + link in a references list. Keep quotes <15 words; paraphrase by default.
