# 00 — Reasoning Engine / เครื่องคิดขั้นสูง

> **id:** `core.reasoning` · **always_on:** true
> **provides:** reasoning, decomposition, tradeoff-analysis, `*`
> **consumes:** `*`
> Use this on EVERY hard task before writing code or design. ใช้ทุกครั้งกับโจทย์ยากก่อนลงมือ

---

## 1. When to engage deep mode / เมื่อไหร่ต้องคิดลึก
Engage full reasoning when ANY is true:
- The task spans more than one module (e.g. web + firebase + design).
- There is a hidden constraint (performance, cost, security, latency, file size).
- A "simple" request hides ambiguity ("make it fast", "make it modern").
- There is more than one correct answer and they trade off against each other.

If none are true, answer directly — do not over-think trivial things.

## 2. The hard-problem loop / ลูปแก้โจทย์ยาก
1. **Restate** the real goal in one sentence. Separate *want* from *stated request*.
2. **Decompose** into independent sub-problems. Tag each with the capability it needs (`design-tokens`, `api-endpoint`, ...). Those tags drive module linking — see `03-composition-rules.md`.
3. **Map unknowns.** Anything volatile (version, price, API shape) → route to `core.research` BEFORE deciding.
4. **Generate ≥2 approaches** for any sub-problem with a real trade-off. Never present the first idea as the only idea.
5. **Score** each approach on: correctness, cost, latency, maintainability, security, and the 25 MB / GitHub constraints.
6. **Decide** and state *why* this beats the runner-up in one line.
7. **Pre-flight check** (`core.errorcheck`) before output.

## 3. Trade-off table template
| Option | Pros | Cons | Cost | Risk | Pick when |
|--------|------|------|------|------|-----------|
| A | … | … | … | … | … |
| B | … | … | … | … | … |

## 4. Reasoning anti-patterns / สิ่งที่ห้ามทำ
- ❌ Pattern-matching to a familiar answer without checking the constraints actually match.
- ❌ Hardcoding a pipeline ("always React + Firebase") when the task does not need it.
- ❌ Hiding assumptions. State every assumption inline so it can be challenged.
- ❌ Skipping the "what would break this?" question.

## 5. Stop conditions / หยุดเมื่อ
Stop reasoning and ask the user ONLY when a missing fact would change the architecture (not the wording). Otherwise proceed and state the assumption.
