# 20 — Web Coding 2026 / เขียนโค้ดเว็บ

> **id:** `web.code`
> **provides:** web-ui, web-api-client, ui-target, frontend
> **consumes:** design-tokens, layout, typography, color, ui-spec, motion, api-endpoint, auth, data-store
> Consumes design from `design.minimal`; consumes backend from `backend.firebase` **only when** auth/data/api is actually needed.

---

## 1. Stack selection (don't hardcode) / เลือกสแตกตามงาน
Choose by need, not habit:
- **Static / content site** → SSG (Astro / Next static / plain HTML+CSS). No backend. Fastest, cheapest, best MX.
- **Interactive app** → React / Next / SvelteKit. Add backend only if there's state to persist.
- **Mobile-shared logic** → Flutter/Dart (and Dart Cloud Functions exists in 2026 if you want one language full-stack).

If there is no data/auth/server need → **do not pull in `backend.firebase`** (anti-rule).

## 2. Machine Experience (MX) baseline / โครงให้ AI อ่านออก
2026 sites are parsed by LLM agents, not just humans:
- Semantic HTML, strict heading hierarchy H1→H6, accurate ARIA, structured data (JSON-LD).
- Lean, server-rendered HTML where possible; avoid unsemantic drag-and-drop bloat.
- This is also the SEO + accessibility win — one effort, three payoffs.

## 3. Consuming design tokens / ใช้โทเคนจากดีไซน์
```css
:root{
  --bg:#0A0A0A; --surface:#141414; --text:#F5F5F5;
  --accent:#4F81BD; --border:#262626; --radius-md:12px;
}
/* tokens come from design.minimal — never hardcode hex in components */
.card{ background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-md); }
```

## 4. Talking to the backend / ต่อกับ backend
When `backend.firebase` provides `api-endpoint`/`auth`/`data-store`:
- Web SDK (modular, tree-shakable). Keep the Gemini/API keys server-side; use Firebase AI Logic so keys never hit the client.
- Real-time UI ← Firestore listeners / SQL Connect realtime sync (paginate; unsubscribe on unmount).
- Auth: passwordless default (email link, OAuth, passkeys); gate UI features on custom claims.
- Add Firebase **App Check** for any AI/sensitive endpoint.

## 5. Performance budget / งบประมาณความเร็ว
- Mobile = ~57–59% of commerce traffic; 0.1s faster load ≈ measurable conversion lift. Treat speed as a feature.
- Image optimization, lazy-loading, code-split, avoid plugin overload.
- Dark-first theme; SVG/CSS first; variable fonts.

## 6. Quality gate / ด่านคุณภาพ
Run `core.errorcheck` Web section. Type-check + lint. Handle loading/empty/error states. No secrets in the bundle. Each built asset ≤ 25 MB (see `91-github-packaging.md`).
