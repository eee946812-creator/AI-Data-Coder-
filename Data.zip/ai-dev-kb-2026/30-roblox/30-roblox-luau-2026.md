# 30 — Roblox Studio / Luau 2026 / เขียนโค้ด Roblox

> **id:** `roblox.luau`
> **provides:** game-logic, game-ui, remote-events, client-server
> **consumes:** reasoning, validation, api-endpoint, data-store, auth, design-tokens
> Consumes `backend.firebase` via HttpService/Open Cloud (hard, when persistence needed); consumes `design.minimal` tokens for GUI (optional).

---

## 1. Language facts (2026) / ข้อเท็จจริงภาษา
- Files use **`.luau`**. Studio warns on legacy `wait()`/`spawn()` → use `task.wait`, `task.spawn`, `task.defer`.
- **New Type Solver + Non-Strict-by-Default** are GA (configurable in Scripting workspace properties).
- Validate with `luau-analyze` / `luau-lsp`; config via `--!strict` comments and `.luaurc`.
- `--!native` compiles hot modules to native code for speed.

## 2. Golden rule / กฎเหล็ก
**Never trust the client.** Every `RemoteEvent`/`RemoteFunction` payload is attacker-controlled. Validate type, range, ownership, and rate on the **server** before acting. Score, currency, and inventory logic live server-side only.

## 3. Project structure / โครงสร้าง
```
ServerScriptService/   -- authoritative logic (Script)
ReplicatedStorage/     -- shared ModuleScripts, types, RemoteEvents
StarterPlayerScripts/  -- client input/UI (LocalScript)
StarterGui/            -- GUI (consumes design.minimal tokens)
```
One file = one exported object; filename matches the export. PascalCase APIs, camelCase locals, `LOUD_SNAKE_CASE` constants, `_private`.

## 4. Typed module pattern / โมดูลแบบมีไทป์
```luau
--!strict
local Wallet = {}
Wallet.__index = Wallet

export type Wallet = typeof(setmetatable({} :: { coins: number }, Wallet))

function Wallet.new(): Wallet
    return setmetatable({ coins = 0 }, Wallet)
end

function Wallet.add(self: Wallet, amount: number): (boolean, string?)
    if typeof(amount) ~= "number" or amount <= 0 then
        return false, "amount must be a positive number"
    end
    self.coins += amount
    return true
end

return Wallet
```
Return `success, err` instead of throwing (throw only to reject invalid usage). Wrap yielding/failable calls in `pcall`.

## 5. Connecting to Firebase / ต่อกับ Firebase
Two safe patterns — pick by need:
- **Roblox DataStore** for in-experience player data (throttle + retry + budget-aware). Default for most games.
- **Firebase as external backend** when you need cross-platform data (web + game share data), analytics, or AI Logic:
  - Server-side `HttpService:RequestAsync` from `ServerScriptService` (never from a LocalScript — keeps secrets off the client).
  - Call a Cloud Function / Cloud Run endpoint that itself talks to Firestore; the game never holds Firebase admin keys.
  - Validate + `pcall` every request; handle offline/timeout; cache hot reads.
```luau
--!strict
local HttpService = game:GetService("HttpService")
local function postScore(userId: number, score: number): boolean
    local ok, res = pcall(function()
        return HttpService:RequestAsync({
            Url = ENDPOINT, -- Cloud Run/Function, NOT Firestore directly
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = HttpService:JSONEncode({ userId = userId, score = score }),
        })
    end)
    return ok and res ~= nil and res.Success == true
end
```

## 6. GUI from shared tokens / GUI ใช้โทเคนร่วม
Read `design.minimal` tokens (color/space/radius) so the game UI matches the web product. Keep GUIs clean: readable text, responsive scaling, smooth button feedback.

## 7. Quality gate / ด่านคุณภาพ
Run `core.errorcheck` Roblox section: `--!strict` clean, server-side validation, no `wait()`/leaks, throttled DataStore, `pcall` on Http/DataStore.
